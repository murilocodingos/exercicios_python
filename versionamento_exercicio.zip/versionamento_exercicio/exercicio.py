#exercício 1
# n1 = float(input('Insira a primeira nota:'))
# n2 = float(input('Insira a segunda nota:'))
# n3 = float(input('Insira a terceira nota:'))
# n4 = float(input('Insira a quarta nota:'))
# n5 = float(input('Insira a quinta nota:'))

# media = (n1+n2+n3+n4+n5) /5

# print(f'A média do aluno é: {media}')


#exercício 2
# valor_real = float(input('Insira um valor em real: '))
# valor_dolar = 0.1751

# resultado_conversao = valor_real * valor_dolar

# print(f'O valor de R${valor_real:,.2f} equivale a ${resultado_conversao:,.2f} USD')


#exercício 3
# salario_atual = float(input('Insira o salário atual do funcionário: '))
# aumento_porcentagem = 0.25

# aumento_salarial = salario_atual * aumento_porcentagem

# salario_novo = salario_atual + aumento_salarial

# print(f'O salário do funcionário com aumento de 25% é: R${salario_novo:,.2f}')


#exercício 5
# numero_pes = float(input('Insira um número em Pés: '))
# numero_polegadas = numero_pes * 12
# numero_jarda = numero_pes / 3
# numero_milha = numero_pes * 5280

# print(f'Polegadas: {numero_milha}')
# print(f'Jardas: {numero_jarda}')
# print(f'Milhas: {numero_milha}')


#exercício 8
# idade = int(input('Insira uma idade: '))

# if idade <= 12:
#     print('É uma criança🧒')
# elif idade >= 13 and idade <= 17:
#     print('É um adolescente😎')
# elif idade >= 18 and idade <= 59:
#     print('É um adulto👨')
# elif idade >= 60:
#     print('É um idoso👴')


#exercício 9
# profissoes = ['Matemático', 'Analista de Sistemas', 'Físico', 'Arquiteto', 'Piloto de Aeronaves']

# numero = int(input("Digite um número de 1 a 5 para escolher uma profissão: "))

# if 1 <= numero <= 5:
#     print(f"A profissão escolhida é: {profissoes[numero - 1]}")
# else:
#     print("Número inválido! Por favor, escolha um número de 1 a 5.")


#exercício 10
# velocidadeMotorista = int(input('A quantos km/h o motorista estava: '))

# if velocidadeMotorista <= 10:
#     print('O Motorista deverá ser multado em R$50,00')
# elif velocidadeMotorista >= 11 and velocidadeMotorista <= 30:
#     print('O motorista deverá ser multado em R$100,00')
# elif velocidadeMotorista >= 31:
#     print('O motorista deverá ser multado em R$200,00')

#exercício 11
# lanches = ['Big Mac', 'Quarteirão', 'McChicken', 'Cheddar McMelt', 'McMax']

# numero = int(input("Digite um número de 1 a 5 para escolher um lanche: "))

# if 1 <= numero <= 5:
#     print(f"O lanche escolhido foi: {lanches[numero - 1]}")
# else:
#     print("Número inválido! Por favor, escolha um número de 1 a 5.")


# #exercício 12
# imc = float(input('Insira uma número imc: '))

# if imc <= 18:
#     print('Magreza')
# elif imc >= 18.1 and imc <= 24.9:
#     print('Saudável')
# elif imc >= 25 and imc <= 29.9:
#     print('Sobrepeso')
# elif imc >= 30:
#     print('Obesidade')

#exercício 31

#Exercício 1
nome = input('Insira seu nome: ')

print(f'Seja bem-vindo {nome}!')

#Exercício 2
palavraUm = input('Insira a primeira palavra: ')
palavraDois = input('Insira a segunda palavra: ')

print(f'{palavraUm} {palavraDois}')

#Exercício 3
contagemFrase = input('Insira uma frase: ').split()

print(f'Essa frase tem {len(contagemFrase)} palavras')

#Exercício 4
numeroUm = int(input('Insira o primeiro número: '))
numeroDois = int(input('Insira o segundo número: '))
soma = numeroUm + numeroDois

print(f'A soma desses dois números é: {soma}')

#Exercício 5
notaUm = int(input('Insira sua primeira nota: '))
notaDois = int(input('Insira sua segunda nota: '))
notaTres = int(input('Insira sua terceira nota: '))

media = (notaUm + notaDois + notaTres) / 3

print(f'Sua média é: {media}')

#Exercício 6
numeroUm = int(input('Insira o primeiro número: '))
numeroDois = int(input('Insira o segundo número: '))
numeroTres = int(input('Insira o terceiro número: '))
listaNumeros = [numeroUm, numeroDois, numeroTres]
maiorNumero = listaNumeros[0]
menorNumero = listaNumeros[0]

for i in listaNumeros:
    if i >= maiorNumero:
        maiorNumero = i
    elif i <= menorNumero:
        menorNumero = i

print(f'O maior número é: {maiorNumero} e o menor é: {menorNumero}')

#Exercício 7
numero = float(input('Insira um número: '))

if numero < 100:
    print('O número inserido é menor do que 100')
elif numero == 100:
    print('O número é igual a 100')
elif numero > 100:
    print('O número é maior que 100')

#Exercício 8
numeroUm = input('Insira o primero número: ')
numeroDois = input('Insira o segundo número: ')
listaNumeros = [numeroUm, numeroDois]
maiorNumero = listaNumeros[0]

if numeroUm == numeroDois:
    print('Os dois número são iguais')
else:
    for i in listaNumeros:
        if i >= maiorNumero:
            maiorNumero = i
            print(f'O maior número é: {maiorNumero}')

#Exercício 9
primeiroLado = input('Insira o primeiro lado: ')
segundoLado = input('Insira o segundo lado: ')
terceiroLado = input('Insira o terceiro lado: ')

if primeiroLado + segundoLado > terceiroLado:
    print('Pode formar um triângulo')
else:
    print('Não pode formar um triângulo')

#Exercício 22
numero = float(input('Insira um número: '))
dobro = numero * 2

print(f'O dobro desse número é: {dobro}')

#Exercício 23
numero = float(input('Insira um número: '))

if numero % 2 == 0:
    print('O número é par')
else:
    print('O número é ímpar')

#Exercício 25
import math

numero = input('Insira um número: ')

raizQuadrada = math.sqrt(numero)

print(raizQuadrada)